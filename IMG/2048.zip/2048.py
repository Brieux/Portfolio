from random import *
from ezTK import*
from ezCLI import *


#Créer et afficher une grille
def initialisation(grille):
    cols=4
    rows=4
    grille = [[0 for i in range(cols)] for j in range(rows)] 
    buildBlock(grille)        #on rentre deux chiffres dans la grille pour commencer a jouer
    buildBlock(grille)

    return (grille) # on a une grille composée de 4 listes contenant quatre 0

def printGrid(grille):
    for i in range(4):
        print (grille[i]) #affichage sous forme de tableau d'une grille composée de 4 listes


def buildBlock(grille):    #genere deux nombres de valeurs aleatoires(10% pour un 4, 90% pour un deux) et de position aléatoire
    b= 0
    b = randrange(0,10)
    if b==0:
        b=4
    else:
        b=2
    for i in range(0,4):
        for j in range(0,4):
            if grille[i][j] == 0 :
                valide = True
            else :
                valide = False
    if valide :            
        row=randrange(0,4)
        col=randrange(0,4)
        while grille[row][col]!=0:
            row=randrange(0,4)
            col=randrange(0,4)
        grille[row][col]=b
 
    return(grille)     

def is_game_over(grille) :            
    #condition 1 : the game is over if there is no empty space
    for i in range(0,4):
        for j in range(0,4):
            if grille[i][j] == 0:
                return False
    #condition 2 : the game is over if there is no deplacement available
    #verification for rows
    for i in range(0,3):
        for j in range(0,4):
            if grille[i][j] == grille[i+1][j]:
                return False

    #verification for cols
    for j in range(0,3):
        for i in range(0,4):
            if grille[i][j] == grille[i][j+1]:
                return False
    #default value if the game is over
    return True

def deplacement(direction, grille):   # deplacement pour chaque direction
    if direction == "UP":             # on deplace vers le haut donc on remonte toutes les valeurs en partant du haut (pas besoin de la premiere ligne)
        compt = 0
        while compt != 3:
            for j in range (0,4):           
                for i in range (1,4):
                        if grille[i-1][j] == 0:
                            grille[i-1][j] = grille[i][j]
                            grille[i][j] = 0
            compt +=1
    
    if direction== "DOWN":        #on deplace vers le bas (derniere ligne non comptee)
        compt = 0
        while compt != 3:
            for j in range (0,4):
                for i in range (2,-1,-1):    # on compte a l'envers
                        if grille[i+1][j] == 0:
                            grille[i+1][j] = grille[i][j]
                            grille[i][j] = 0
            compt +=1

    if direction == "LEFT":
        compt = 0
        while compt != 3:
            for i in range (0,4):
                for j in range (1,4):
                        if grille[i][j-1] == 0:
                            grille[i][j-1] = grille[i][j]
                            grille[i][j] = 0
            compt +=1
            

    if direction == "RIGHT":
        compt = 0
        while compt != 3:
            for i in range (0,4):
                for j in range (2,-1,-1):
                        if grille[i][j+1] == 0:
                            grille[i][j+1] = grille[i][j]
                            grille[i][j] = 0
            compt +=1

     
    return grille

def fusion(direction,grille):          # fusion pour chaque deplacement on procede comme pour la fonction deplacement et si deux valeurs cote a cote sont egales on dit que la premiere valeur dans le sens du deplacement est egale a deux fois la seconde et la seconde est reinitialisée a zero.

    if direction == "UP":
        for i in range (0,3):               
            for j in range(0,4):
                if grille[i][j] == grille[i+1][j]:
                    grille[i][j] += grille[i+1][j]
                    grille[i+1][j] = 0

    if direction == "DOWN":
        for i in range (3,0,-1):
            for j in range(0,4):
                if grille[i][j] == grille[i-1][j]:
                    grille[i][j] += grille[i-1][j]
                    grille[i-1][j] = 0

    if direction == "LEFT":
        for j in range (0,3):
            for i in range(0,4):
                if grille[i][j] == grille[i][j+1]:
                    grille[i][j] += grille[i][j+1]
                    grille[i][j+1] = 0

    if direction == "RIGHT":
        for j in range (3,0,-1):
            for i in range(0,4):
                if grille[i][j] == grille[i][j-1]:
                    grille[i][j] += grille[i][j-1]
                    grille[i][j-1] = 0
    return grille

def move(direction,grille,value,max_cell): #cette fonction permet de réaliser le déplacement enfonction de la fléche qui a été touché sur le clavier par l'utilisateur
    grille = deplacement(direction, grille)
    grille = fusion(direction,grille)
    grille = deplacement(direction, grille)
    grille = buildBlock(grille)
    actualise(grille)
    for i in range (0,4): #cette boucle permet de mettre à jour le score du joueur
        for j in range (0,4):
            value += grille[i][j]
            valeur['text']=value
            if grille[i][j] > max_cell:
                max_cell = grille[i][j]
    if is_game_over(grille) == True : #cette boucle permet d'indiquer par l'ouverture d'une fenêtre que le joueur à perdu
        highscore = open("highscore","r+")
        r=highscore.read()
        if str(value)>highscore.read():
            new=r.replace(r,str(value))
            write_txt("highscore",new) #le meilleur score a été modifié dans le fichier
            win_loose_BS=Win(title='THE END')
            Label(win_loose_BS, text='Plus de déplacement \n Vous avez perdu mais vous avez battu le meilleur score !')
            Button(win_loose_BS,text='BACK TO MENU', command=lambda:menu(win))   # on retourne dans la fonction menu en lui envoyant la fenêtre du main pour qu'il l'a supprime                  
            Button(win_loose_BS,text='EXIT', command=lambda:win.exit())
        else:
            win_loose=Win(title='THE END')
            Label(win_loose, text='Plus de déplacement \n Vous avez perdu !')
            Button(win_loose,text='BACK TO MENU', command=lambda:menu(win))   # on retourne dans la fonction menu en lui envoyant la fenêtre du main pour qu'il l'a supprime                  
            Button(win_loose,text='EXIT', command=lambda:win.exit())        
            
def actualise(grille): #permet de mettre à jour l'interface graphique
    for k in range(0,4):
        for l in range(0,4):
            if grille[k][l]==0:
                fr1[k][l]['text']= ''
            else :
                fr1[k][l]['text']=grille[k][l]
    
                
def on_key(widget, code, mods): #to play with your keyboard, more funny
    moves = {'Up':0, 'Down':1, 'Right':2, 'Left':3}
    if code not in ('Up','Down','Right','Left'): return
    if moves[code]==0: move("RIGHT",grille,value,max_cell) #j'ai mis direction=RIGHT car en testant, c'était que comme cela que cela fonctionnait
    elif moves[code]==1: move("LEFT",grille,value,max_cell)
    elif moves[code]==2: move("DOWN",grille,value,max_cell)
    else: move("UP",grille,value,max_cell) 
    
    
    
def menu(win=None,height=12,width=6):             # win a comme valeur par défaut None dans le cas où on appel menu sans lui donner de variable
                                # j'ai mis win en variable car vu qu'on commence par menu la win n'existe pas encore donc ça bug
    global win_menu              # on enregistre la fenêtre win_menu en global pour l'utiliser dans le reste de la page
    if win:                       # si win est différent de None on supprime la fenêtre
        win.exit()
    
    win_menu = Win(title='2048 - MENU')                                        
    frame = Frame(win_menu, flow='SE')                       
    font = 'Arial 14 bold'
    fg = '#FFFFFF'
  
    bg=('SkyBlue1','#0C0','#C00')
    
    fr1=Frame(frame,flow='ES') #fenêtre où se trouve les scores
    Label(fr1,text="Best score :",justify='left')
    highscore = open("highscore","r+")
    r=highscore.read()
    Label(fr1,text=r,justify='left')
    
    fr2=Frame(frame,border=1)
    Label(fr2,text="2",bg=bg[0], height=6, width=4,font=font,justify='left')
    Label(fr2,text="0",bg=bg[0], height=6,width=4,font=font,justify='left')
    Label(fr2,text="4",bg=bg[0], height=6,width=4,font=font,justify='left')
    Label(fr2,text="8",bg=bg[0], height=6,width=4,font=font,justify='left')
    fr3=Frame(frame,op=3)
    Button(fr3,text='PLAY', bg=bg[1], font=font, relief='raised', command=lambda:main())    #bouton qui permet de jouer               
    Button(fr3,text='EXIT', bg=bg[2], font=font,relief='raised',command=lambda:win_menu.exit()) #bouton qui permet de quitter la fenêtre

    win_menu.loop()
  
def main():
    global grille,fr1,valeur,value,max_cell,win
    font = 'Arial 14 bold'
    fg = '#FFFFFF'
  
    bg=('light slate gray','#0C0','#C00')
    if win_menu:                  # Si il existe une fenêtre win_menu on la ferme
          win_menu.exit()
  
  
    win = Win(title='2048', key=on_key)                                        
    frame = Frame(win,flow='ES',fold=2)
    highscore = open("highscore","r+")
    r=highscore.read()
    Label(frame,text="Best score :",bg=bg[0], width=20, font=font,fg=fg,justify='left')
    Label(frame,text=r,bg=bg[0], width=20, font=font,fg=fg,justify='left')
    value = 0
    Label(frame,text="Score :",bg=bg[0], width=20, font=font,fg=fg,justify='left')
    valeur=Label(frame,text=value,bg=bg[0], width=20, font=font,fg=fg,justify='left')
    
    fr1=Frame(frame,flow='NE',fold=4,bg=bg[0],op=3,border=1)
    
    for i in range (0,16): #créer les 16 cases nécessaires au jeu
            Label(fr1,height=6, width=5,bg='light grey')
    
    grille=[[],[],[],[]] # grille vide
    max_cell = 0 #max_cell à 0 au début
    grille=initialisation(grille) #on initialise
    actualise(grille) #on actualise et c'est parti
    fr3=Frame(win,flow='ES',op=4,bg=bg[0])        
    Button(fr3,text='BACK TO MENU',bg='gray80',fg='black', command=lambda:menu(win),relief='raised')   # on retourne dans la fonction menu en lui envoyant la fenêtre du main pour qu'il l'a supprime                  
    Button(fr3,text='EXIT',bg='gray80',fg='black', command=lambda:win.exit(),relief='raised')
    win.loop()

  
if __name__ == "__main__":
    menu()
    

    
